/*
 * eeprom.c
 *
 *  Created on: 2022��3��8��
 *      Author: 93793
 */


#include "headfile.h"
#include "eeprom.h"

/*-------------------------------------------------------------------
 * ��     Name  ��: <EPROM_IIC_init>
 * �� Describe��: <This function is used to initialize IIC device
 * 					of EEPROM.>
 * ��Parameter��:none
 * ��  Example ��:<EPROM_IIC_init(void);.>
 *------------------------------------------------------------------*/
void EPROM_IIC_init(void)
{
	//����ģ��ʱ��
	IIC_Master_disable(EEPROM_IIC_DEVICE_ADDR);//disable IIC device
	IIC_Master_unlockeddiv(EEPROM_IIC_DEVICE_ADDR);//unlocked IIC division register
	IIC_Master_write_DIV0(EEPROM_IIC_DEVICE_ADDR,4);//config IIC clock :  IIC_CLK = clk_source/10
	IIC_Master_write_DIV1(EEPROM_IIC_DEVICE_ADDR,10);//config IIC pulse_width :  pulse_width = 10*IIC_CLK
	IIC_Master_lockeddiv(EEPROM_IIC_DEVICE_ADDR);//lock IIC division register
	IIC_Master_reset(EEPROM_IIC_DEVICE_ADDR);//reset IIC device
	IIC_Master_enable(EEPROM_IIC_DEVICE_ADDR);//enable IIC device
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <EEPROM_write_Byte>
 * �� Describe��: <This function is used to write an byte data to
 * 					EEPROM.>
 * ��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data: the data which will be written to EEPROM.>
 * ��  Example ��:<EEPROM_write_Byte(0x00 , 0x01 , 0x01);
 * 			      The example write a data 0x01 to EEPROM at page 0
 * 			      and address 0x01.>
 *------------------------------------------------------------------*/
uint8 EEPROM_write_Byte(uint8 page , uint8 addr , uint8 data)
{
	IIC_Master_send_start(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,(EEPROM_ADDR<<2)|(page<<1)|0x00);//send EEPROM device address and pages at write mode

    if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
    {
       IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
       return 245;
    }
    IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,addr);//send data address
    if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
    {
       IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
       return 240;
    }
    IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,data);//send data
    if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
    {
      IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
      return 235;
    }
    IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);
    EEPROM_DELAY;
    return 0;
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <EEPROM_write_len>
 * �� Describe��: <This function is used to continuous write datas to
 * 					EEPROM.>
 * ��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data: the data buffer which will be written to EEPROM.
 * 				  len: the length of data buffer.
 * 				 >
 * ��  Example ��:<EEPROM_write_len(0x00 , 0x01 , data,12);
 * 			      The example write an array with length of 12 to EEPROM
 * 			      at page 0 and address 0x01.>
 * 			      _____________________________________________________
 * 			      **tips: the length of data buffer must less than 16(len < 16)
 *------------------------------------------------------------------*/
uint8 EEPROM_write_len(uint8 page , uint8 addr , uint8 * data , uint8 len)
{
	uint8 i;
	IIC_Master_send_start(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,(EEPROM_ADDR<<2)|(page<<1)|0x00);//send EEPROM device address and pages at write mode
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	   IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	   return 245;
	}
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,addr);//send data address
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	   IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	   return 240;
	}

	for(i = 0 ; i < len ; i++)
	{
		IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,*data);//send data
	   if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	   {
		 IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
		 return 235;
	   }
	   data++;
	}
	IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);
	EEPROM_DELAY;

	return 0;
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <EEPROM_read_Byte>
 * �� Describe��: <This function is used to read an byte data from
 * 					EEPROM and return an 8bits data.>
 * ��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.>
 * ��  Example ��:<EEPROM_read_Byte(0x00 , 0x01);
 * 			      The example read a data from EEPROM at page 0 and address
 * 			      0x01.>
 *------------------------------------------------------------------*/
uint8 EEPROM_read_Byte(uint8 page , uint8 addr)
{
	uint8 tmp;
	IIC_Master_send_start(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,(EEPROM_ADDR<<2)|(page<<1)|0x00);//send EEPROM device address and pages at write mode
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	   IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	   return 245;
	}
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,addr);//send data address
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	   IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	   return 240;
	}
	IIC_Master_send_start(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,(EEPROM_ADDR<<2)|(page<<1)|0x01);//send EEPROM device address and pages at read mode
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	  IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	  return 235;
	}
	tmp = IIC_Master_recv_byte(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_ack(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);
	return tmp;
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <EEPROM_read_len>
 * �� Describe��: <This function is used to continuous read datas from
 * 					EEPROM.>
 * ��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data_buf: the data buffer used to store data from EEPROM.
 * 				  len: the length of data buffer.
 * 				 >
 * ��  Example ��:<EEPROM_read_len(0x00 , 0x01 , data_buf , 12);
 * 			      The example read an array with length of 12 from EEPROM
 * 			      at page 0 and address 0x01.>
 * 			      _____________________________________________________
 * 			      **tips: the length of data buffer must less than 16(len < 16)
 *------------------------------------------------------------------*/
uint8 EEPROM_read_len(uint8 page , uint8 addr , uint8 * data_buf , uint8 len)
{
	uint8 i;
	IIC_Master_send_start(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,(EEPROM_ADDR<<2)|(page<<1)|0x00);//send EEPROM device address and pages at write mode
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	   IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	   return 245;
	}
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,addr);//send data address
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	   IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	   return 240;
	}
	IIC_Master_send_start(EEPROM_IIC_DEVICE_ADDR);
	IIC_Master_send_byte(EEPROM_IIC_DEVICE_ADDR,(EEPROM_ADDR<<2)|(page<<1)|0x01);//send EEPROM device address and pages at read mode
	if(!IIC_Master_check_ack(EEPROM_IIC_DEVICE_ADDR))
	{
	  IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);//when checked an no-ack signal, send a stop signal
	  return 235;
	}
	for(i = 0 ; i < len ; i++)
   {
	   if( i != len-1)
	   {
		   data_buf[i] = IIC_Master_recv_byte(EEPROM_IIC_DEVICE_ADDR);
		   IIC_Master_send_ack(EEPROM_IIC_DEVICE_ADDR);//IIC Master send an ack signal
	   }
	   else
	   {
		   data_buf[i] = IIC_Master_recv_byte(EEPROM_IIC_DEVICE_ADDR);
		   IIC_Master_send_nack(EEPROM_IIC_DEVICE_ADDR);//IIC Master send an no-ack signal
	   }
   }
	IIC_Master_send_stop(EEPROM_IIC_DEVICE_ADDR);
	return 0;
}


/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_write_int>
 *�� Describe��:<the function is used to write an 32bits data to EEPROM>
 *			 <the data will be stored at the form below.>
 *			   _______________________________
	 address->| addr  |addr+1 | addr+2|addr+3 |
			  |_______|_______|_______|_______|
			  |       |       |       |       |
			  | L 8bs | H 8bs | L 8bs | H 8bs |
			  |_______|_______|_______|_______|
			  |   Low 16bits  |  High 16bits  |
			  |_______________|_______________|
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data: the int data written to EEPROM.
 * 				 >
 *��  Example ��:
           EEPROM_write_int(0 , 0x01 ,128);
           the example write an int data 128 to EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
uint8 EEPROM_write_int(uint8 page , uint8 addr , int32 data)
{
    uint8 error_flag;
    int_chr_convertor.data = data;
    error_flag = EEPROM_write_len(page , addr , int_chr_convertor.data_buf , 4);
    EEPROM_DELAY;
    return error_flag;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_write_short>
 *�� Describe��:<the function is used to write a 16bits data to EEPROM>
 *			 <the data will be stored at the form below.>
 *			   ________________
	 address->| addr  |addr+1 |
			  |_______|_______|
			  |       |       |
			  | L 8bs | H 8bs |
			  |_______|_______|
			  |    16bits     |
			  |_______________|
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data: the short data written to EEPROM.
 * 				 >
 *��  Example ��:
           EEPROM_write_short(0 , 0x01 ,12);
           the example write an short data 12 to EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
uint8 EEPROM_write_short(uint8 page , uint8 addr , int16 data)
{
    uint8 error_flag;
    short_chr_convertor.data = data;
    error_flag = EEPROM_write_len(page , addr , short_chr_convertor.data_buf , 2);
    EEPROM_DELAY;
    return error_flag;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_write_float>
 *�� Describe��:<the function is used to write a float data to EEPROM
 *��				it will take 4 Bytes ROM spaces.>
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data: the float data written to EEPROM.
 * 				 >
 *��  Example ��:
           EEPROM_write_float(0 , 0x01 ,0.125);
           the example write a float data 0.125 to EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
uint8 EEPROM_write_float(uint8 page , uint8 addr , float data )
{
	uint8 error_flag;
	flt_chr_convertor.data = data;
	error_flag = EEPROM_write_len(page , addr , flt_chr_convertor.data_buf , 4);
    EEPROM_DELAY;
	return error_flag;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_write_double>
 *�� Describe��:<the function is used to write a double data to EEPROM
 *��				it will take 8 Bytes ROM spaces.>
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 data: the double data written to EEPROM.
 * 				 >
 *��  Example ��:
           EEPROM_write_double(0 , 0x01 ,0.125);
           the example write a double data 0.125 to EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
uint8 EEPROM_write_double(uint8 page , uint8 addr , double data)
{
    uint8 error_flag;
    dub_chr_convertor.data = data;
    error_flag = EEPROM_write_len(page , addr , dub_chr_convertor.data_buf , 8);
    EEPROM_DELAY;
    return error_flag;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_read_int>
 *�� Describe��:<the function is used to read an int data from EEPROM
 *               and return a 32bits data.>
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 >
 *��  Example ��:
           EEPROM_read_int(0 , 0x01 );
           the example reads an int data from EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
int32 EEPROM_read_int(uint8 page , uint8 addr)
{
    uint8 error_flag;
    int data;
    error_flag = EEPROM_read_len(page , addr , int_chr_convertor.data_buf , 4);
    if(!error_flag )
    {
        data = int_chr_convertor.data ;
    }
    else
    {
        data = 999;
    }

    return data;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_read_short>
 *�� Describe��:<the function is used to read a short data from EEPROM
 *               and return a 16bits data.>
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 >
 *��  Example ��:
           EEPROM_read_short(0 , 0x01 );
           the example reads a short data from EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
int16 EEPROM_read_short(uint8 page , uint8 addr)
{
    uint8 error_flag;
    short data;
    error_flag = EEPROM_read_len(page , addr , short_chr_convertor.data_buf , 2);
    if(!error_flag)
    {
        data = short_chr_convertor.data ;
    }
    else
    {
        data = 999 ;
    }
    return data;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_read_float>
 *�� Describe��:<the function is used to read a float data from EEPROM
 *               and return a float data.>
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 >
 *��  Example ��:
           EEPROM_read_float(0 , 0x01 );
           the example reads a float data from EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
float EEPROM_read_float(uint8 page , uint8 addr)
{
       uint8 error_flag;
       float data;
       error_flag = EEPROM_read_len(page , addr , flt_chr_convertor.data_buf , 4);

       if(!error_flag )
       {
           data = flt_chr_convertor.data;
       }
       else
       {
           data = 999;
       }
       return data;
}

/*-------------------------------------------------------------------
 *��     Name  ��:<EEPROM_read_double>
 *�� Describe��:<the function is used to read a double data from EEPROM
 *               and return a double data.>
 *��Parameter��:<page: select EEPROM at24c04 page, it can be 0x00 or
 * 						 0x01.
 * 				 addr: select EEPROM at24c04 data address, it can be
 * 				 		set a value ranging from 0x00 to 0xff.
 * 				 >
 *��  Example ��:
           EEPROM_read_double(0 , 0x01 );
           the example reads a double data from EEPROM at page 0
           and address 0x01
 *------------------------------------------------------------------*/
double EEPROM_read_double(uint8 page , uint8 addr)
{
       uint8 error_flag;
       double data;
       error_flag = EEPROM_read_len(page , addr , dub_chr_convertor.data_buf , 8);

       if(!error_flag )
       {
           data = dub_chr_convertor.data;
       }
       else
       {
           data = 999;
       }
       return data;
}

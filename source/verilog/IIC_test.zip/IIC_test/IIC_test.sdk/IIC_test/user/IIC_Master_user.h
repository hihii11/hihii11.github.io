/*
 * IIC_Master_user.h
 *
 *  Created on: 2022��3��4��
 *      Author: 93793
 */

#ifndef USER_IIC_MASTER_USER_H_
#define USER_IIC_MASTER_USER_H_
#include "IIC_Master_2.h"

//IIC_Master BaseAddress
#define IIC_Master_0                          (unsigned int)(0x43C00000)         //<the base address of IIC Master0>

//IIC_Master register offset define
#define IIC_Master_CTL0                       (unsigned int)(0x00000000)         //<the offset of IIC control Register>
#define IIC_Master_SEL0                       (unsigned int)(0x00000004)         //<the offset of IIC events select Register>
#define IIC_Master_SEDBUFF                    (unsigned int)(0x00000008)         //<the offset of IIC send buffer Register>
#define IIC_Master_RECBUFF                    (unsigned int)(0x0000000C)         //<the offset of IIC receive data Register>
#define IIC_Master_IFG                        (unsigned int)(0x00000010)         //<the offset of IIC events flag Register>
#define IIC_Master_DIV0                       (unsigned int)(0x00000014)         //<the offset of IIC clock division Register>
#define IIC_Master_DIV1                       (unsigned int)(0x00000018)         //<the offset of IIC pulse period division Register>

//IIC_Master CTL0 register bits function define
#define IIC_Master_CTL0_FREE                  (unsigned int)(0x00000000)    //<To leave IIC CTL0 register idle>
#define IIC_Master_EN                         (unsigned int)(0x00000001)    //<To enable IIC Master>
#define IIC_Master_RST                        (unsigned int)(0x00000002)    //<To reset IIC Master>
#define IIC_Master_START                      (unsigned int)(0x00000004)    //<To start a IIC Master event>
#define IIC_Master_UNLOCKED                   (unsigned int)(0x00000008)    //<To unlock the clock div0-div1 Registers>
#define IIC_Master_LOCKED                     (unsigned int)(0x00000000)    //<To lock the clock div0-div1 Registers>

//IIC_Master SEL0 register bits function define
#define IIC_Master_SEL0_FREE                  (unsigned int)(0x00000000)    //<To leave IIC Master SEL0 register idle>
#define IIC_Master_SEL0_START                 (unsigned int)(0x00000001)    //<To send a IIC start signal>
#define IIC_Master_SEL0_SENDBYTE              (unsigned int)(0x00000002)    //<To send a byte data from send buff Register>
#define IIC_Master_SEL0_SENDACK               (unsigned int)(0x00000004)    //<To send a IIC ack signal>
#define IIC_Master_SEL0_SENDNACK              (unsigned int)(0x00000008)    //<To send a IIC no ack signal>
#define IIC_Master_SEL0_STOP                  (unsigned int)(0x00000010)    //<To send a IIC stop signal>
#define IIC_Master_SEL0_RECVBYTE              (unsigned int)(0x00000020)    //<To receive a byte data from slave>
#define IIC_Master_SEL0_CHECKACK              (unsigned int)(0x00000040)    //<To check if IIC Master has receive a ack signal>


//IIC_Master IFG register bits function define
#define IIC_Master_BUSYIFG                    (unsigned int)(0x00000002)    //<means IIC Master has a processing>
#define IIC_Master_EVENTIFG                   (unsigned int)(0x00000001)    //<means IIC Master has ended an event>
#define IIC_Master_STARTIFG                   (unsigned int)(0x00000008)    //<means IIC Master has ended sending a start signal processing>
#define IIC_Master_SENDBYTEIFG                (unsigned int)(0x00000010)    //<means IIC Master has ended sending a byte data processing>
#define IIC_Master_SENDACKIFG                 (unsigned int)(0x00000020)    //<means IIC Master has ended sending an ack signal processing>
#define IIC_Master_SENDNACKIFG                (unsigned int)(0x00000040)    //<means IIC Master has ended sending an no-ack signal processing>
#define IIC_Master_STOPIFG                    (unsigned int)(0x00000080)    //<means IIC Master has ended sending a stop signal processing>
#define IIC_Master_RECVBYTEIFG                (unsigned int)(0x00000100)    //<means IIC Master has receive a byte data>
#define IIC_Master_ACKCHECKIFG                (unsigned int)(0x00000004)    //<means IIC Master has checked an ack signal>
#define IIC_Master_NACKCHECKIFG               (unsigned int)(0x00000000)    //<means IIC Master has checked an no-ack signal>

#define  IIC_AXI_delay                        usleep(10);

extern void IIC_Master_enable(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_disable(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_lockeddiv(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_unlockeddiv(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_reset(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_eventstart(AXI_BaseAddress_Data_Type Base_addr);
extern uint16 IIC_Master_read_IFG(AXI_BaseAddress_Data_Type Base_addr);
extern uint8 IIC_Master_read_CTL0(AXI_BaseAddress_Data_Type Base_addr);
extern uint8 IIC_Master_read_SEL0(AXI_BaseAddress_Data_Type Base_addr);
extern uint8 IIC_Master_read_SENDBUF(AXI_BaseAddress_Data_Type Base_addr);
extern uint8 IIC_Master_read_RECBUF(AXI_BaseAddress_Data_Type Base_addr);
extern uint16 IIC_Master_read_DIV0(AXI_BaseAddress_Data_Type Base_addr);
extern uint16 IIC_Master_read_DIV1(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_write_CTL0(AXI_BaseAddress_Data_Type Base_addr, uint8 data);
extern void IIC_Master_write_SEL0(AXI_BaseAddress_Data_Type Base_addr, uint8 data);
extern void IIC_Master_write_SENDBUFF(AXI_BaseAddress_Data_Type Base_addr, uint8 data);
extern void IIC_Master_write_DIV0(AXI_BaseAddress_Data_Type Base_addr, uint16 data);
extern void IIC_Master_write_DIV1(AXI_BaseAddress_Data_Type Base_addr, uint16 data);
extern void IIC_Master_send_start(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_send_byte(AXI_BaseAddress_Data_Type Base_addr,uint8 data);
extern void IIC_Master_send_ack(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_send_nack(AXI_BaseAddress_Data_Type Base_addr);
extern void IIC_Master_send_stop(AXI_BaseAddress_Data_Type Base_addr);
extern uint8 IIC_Master_recv_byte(AXI_BaseAddress_Data_Type Base_addr);
extern uint8 IIC_Master_check_ack(AXI_BaseAddress_Data_Type Base_addr);

#endif /* USER_IIC_MASTER_USER_H_ */

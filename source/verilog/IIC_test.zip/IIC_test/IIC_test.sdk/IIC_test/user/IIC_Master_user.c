/*
 * IIC_Master_user.c
 *
 *  Created on: 2022��3��4��
 *      Author: 93793
 */
#include "headfile.h"
#include "IIC_Master_user.h"

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_enable>
 * �� Describe��: <The IIC module at the base address of
 * 				 "Base_addr" can use this function to
 * 				 	enable it.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_enable(IIC_Master_0);
 * 				 The example enable the "IIC_Master_0" device.>
 *------------------------------------------------------------------*/
void IIC_Master_enable(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_EN;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_disable>
 * �� Describe��: <The IIC module at the base address of
 * 				 "Base_addr" can use this function to
 * 				 	disable it.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_disable(IIC_Master_0);
 * 				 The example disable the "IIC_Master_0" device.>
 *------------------------------------------------------------------*/
void IIC_Master_disable(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status &= ~IIC_Master_EN;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_reset>
 * �� Describe��: <The function can reset the IIC module.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_reset(IIC_Master_0);
 * 				 The example reset the "IIC_Master_0" device.>
 *------------------------------------------------------------------*/
void IIC_Master_reset(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_RST;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	IIC_AXI_delay;
	CTL0_status &= ~IIC_Master_RST;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_eventstart>
 * �� Describe��: <The function can start an IIC event of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_eventstart(IIC_Master_0);
 * 				 The example start an event of "IIC_Master_0" device.>
 *------------------------------------------------------------------*/
void IIC_Master_eventstart(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_lockeddiv>
 * �� Describe��: <The function can lock the clock frequency division
 * 					registers of IIC module and when the function is
 * 					called the values of division registers can not
 * 					be visited.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_divlocked(IIC_Master_0);
 * 				 The example lock the division registers of "IIC_Master_0"
 * 				 device and the value of division registers can not
 * 				 be visited.>
 *------------------------------------------------------------------*/
void IIC_Master_lockeddiv(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status &= ~IIC_Master_UNLOCKED;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_unlockeddiv>
 * �� Describe��: <The function can unlock the clock frequency division
 * 					registers of IIC module and when the function is
 * 					called the values of division registers can
 * 					be visited.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_divunlocked(IIC_Master_0);
 * 				 The example unlock the division registers of "IIC_Master_0"
 * 				 device and the value of division registers can
 * 				 be visited.>
 *------------------------------------------------------------------*/
void IIC_Master_unlockeddiv(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_UNLOCKED;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_readIFG>
 * �� Describe��: <This function can be used to get event flags from
 * 					the IFG Register of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_readIFG(IIC_Master_0);
 * 				 The example read the IFG register of IIC_Master device
 * 				 and return a 16'bits data.>
 *------------------------------------------------------------------*/
uint16 IIC_Master_read_IFG(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type IFG_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG);
	return (uint16)(IFG_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_read_CTL0>
 * �� Describe��: <This function can read CTL0 register of IIC_Master
 * 					device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_read_CTL0(IIC_Master_0);
 * 				 The example read the CTL0 register of IIC_Master device
 * 				 and return a 8'bits data.>
 *------------------------------------------------------------------*/
uint8 IIC_Master_read_CTL0(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	return (uint8)(CTL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_read_SEL0>
 * �� Describe��: <This function can read SEL0 register of IIC_Master
 * 					device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_read_SEL0(IIC_Master_0);
 * 				 The example read the SEL0 register of IIC_Master device
 * 				 and return a 8'bits data.>
 *------------------------------------------------------------------*/
uint8 IIC_Master_read_SEL0(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type SEL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_SEL0);
	return (uint8)(SEL0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_read_SENDBUF>
 * �� Describe��: <This function can read SENDBUF register of IIC_Master
 * 					device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_read_SENDBUF(IIC_Master_0);
 * 				 The example read the SENDBUF register of IIC_Master device
 * 				 and return a 8'bits data.>
 *------------------------------------------------------------------*/
uint8 IIC_Master_read_SENDBUF(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type SENDBUF_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_SEDBUFF);
	return (uint8)(SENDBUF_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_read_RECBUF>
 * �� Describe��: <This function can read RECBUF register of IIC_Master
 * 					device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_read_SENDBUF(IIC_Master_0);
 * 				 The example read the RECBUF register of IIC_Master device
 * 				 and return a 8'bits data.>
 *------------------------------------------------------------------*/
uint8 IIC_Master_read_RECBUF(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type RECBUF_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_RECBUFF);
	return (uint8)(RECBUF_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_read_DIV0>
 * �� Describe��: <This function can read DIV0 register of IIC_Master
 * 					device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_read_DIV0(IIC_Master_0);
 * 				 The example read the DIV0 register of IIC_Master device
 * 				 and return a 16'bits data.>
 *------------------------------------------------------------------*/
uint16 IIC_Master_read_DIV0(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type DIV0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_DIV0);
	return (uint16)(DIV0_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_read_DIV1>
 * �� Describe��: <This function can read DIV1 register of IIC_Master
 * 					device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_read_DIV1(IIC_Master_0);
 * 				 The example read the DIV1 register of IIC_Master device
 * 				 and return a 16'bits data.>
 *------------------------------------------------------------------*/
uint16 IIC_Master_read_DIV1(AXI_BaseAddress_Data_Type Base_addr)
{
	AXI_Register_Data_Type DIV1_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_DIV1);
	return (uint16)(DIV1_status);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_write_CTL0>
 * �� Describe��: <This function can write a 8bits data to CTL0 register
 * 					of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * 				 <data     : The data value which will be written to
 * 				 			  CTL0 register.>
 * ��  Example ��:<IIC_Master_write_CTL0(IIC_Master_0,data);
 * 				 The example write the data to CTL0 register of IIC_Master_0.>
 *------------------------------------------------------------------*/
void IIC_Master_write_CTL0(AXI_BaseAddress_Data_Type Base_addr, uint8 data)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0, (AXI_Register_Data_Type)(data));
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_write_SEL0>
 * �� Describe��: <This function can write a 8bits data to SEL0 register
 * 					of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * 				 <data     : The data value which will be written to
 * 				 			  SEL0 register.>
 * ��  Example ��:<IIC_Master_write_SEL0(IIC_Master_0,data);
 * 				 The example write the data to SEL0 register of IIC_Master_0.>
 *------------------------------------------------------------------*/
void IIC_Master_write_SEL0(AXI_BaseAddress_Data_Type Base_addr, uint8 data)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, (AXI_Register_Data_Type)(data));
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_write_SENDBUFF>
 * �� Describe��: <This function can write a 8bits data to SENDBUFF register
 * 					of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * 				 <data     : The data value which will be written to
 * 				 			  SENDBUFF register.>
 * ��  Example ��:<IIC_Master_write_SENDBUFF(IIC_Master_0,data);
 * 				 The example write the data to SENDBUFF register of IIC_Master_0.>
 *------------------------------------------------------------------*/
void IIC_Master_write_SENDBUFF(AXI_BaseAddress_Data_Type Base_addr, uint8 data)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEDBUFF, (AXI_Register_Data_Type)(data));
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_write_DIV0>
 * �� Describe��: <This function can write a 16bits data to DIV0 register
 * 					of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * 				 <data     : The data value which will be written to
 * 				 			  DIV0 register.>
 * ��  Example ��:<IIC_Master_write_DIV0(IIC_Master_0,data);
 * 				 The example write the data to DIV0 register of IIC_Master_0.>
 *------------------------------------------------------------------*/
void IIC_Master_write_DIV0(AXI_BaseAddress_Data_Type Base_addr, uint16 data)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_DIV0, (AXI_Register_Data_Type)(data));
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_write_DIV1>
 * �� Describe��: <This function can write a 16bits data to DIV1 register
 * 					of IIC_Master device.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * 				 <data     : The data value which will be written to
 * 				 			  DIV1 register.>
 * ��  Example ��:<IIC_Master_write_DIV1(IIC_Master_0,data);
 * 				 The example write the data to DIV1 register of IIC_Master_0.>
 *------------------------------------------------------------------*/
void IIC_Master_write_DIV1(AXI_BaseAddress_Data_Type Base_addr, uint16 data)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_DIV1, (AXI_Register_Data_Type)(data));
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_send_start>
 * �� Describe��: <This function start a processing of sending a start signal.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_send_start(IIC_Master_0);
 * 				 The example will let IIC_Master device send a start signal .>
 *------------------------------------------------------------------*/
void IIC_Master_send_start(AXI_BaseAddress_Data_Type Base_addr)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_START);
	IIC_AXI_delay;
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_send_ack>
 * �� Describe��: <This function start a processing of sending an ack signal.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_send_ack(IIC_Master_0);
 * 				 The example will let IIC_Master device send an ack signal .>
 *------------------------------------------------------------------*/
void IIC_Master_send_ack(AXI_BaseAddress_Data_Type Base_addr)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_SENDACK);
	IIC_AXI_delay;
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_send_nack>
 * �� Describe��: <This function start a processing of sending an nack signal.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_send_ack(IIC_Master_0);
 * 				 The example will let IIC_Master device send an nack signal .>
 *------------------------------------------------------------------*/
void IIC_Master_send_nack(AXI_BaseAddress_Data_Type Base_addr)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_SENDNACK);
	IIC_AXI_delay;
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_send_byte>
 * �� Describe��: <This function start a processing of sending a byte data.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_send_byte(IIC_Master_0);
 * 				 The example will let IIC_Master device send a byte data.>
 *------------------------------------------------------------------*/
void IIC_Master_send_byte(AXI_BaseAddress_Data_Type Base_addr,uint8 data)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_SENDBYTE);
	IIC_AXI_delay;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEDBUFF, data);
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_send_stop>
 * �� Describe��: <This function start a processing of sending a stop signal.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_send_stop(IIC_Master_0);
 * 				 The example will let IIC_Master device send a stop signal.>
 *------------------------------------------------------------------*/
void IIC_Master_send_stop(AXI_BaseAddress_Data_Type Base_addr)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_STOP);
	IIC_AXI_delay;
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_recv_byte>
 * �� Describe��: <This function start a processing of receiving a byte data
 * 					and return an 8bits data.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_recv_byte(IIC_Master_0);
 * 				 The example will let IIC_Master device receive a byte data.>
 *------------------------------------------------------------------*/
uint8 IIC_Master_recv_byte(AXI_BaseAddress_Data_Type Base_addr)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_RECVBYTE);
	IIC_AXI_delay;
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);

	return (uint8)(IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_RECBUFF));
}

/*-------------------------------------------------------------------
 * ��     Name  ��: <IIC_Master_check_ack>
 * �� Describe��: <This function start a processing of checking an ack signal
 * 					from slave and return "1" when checked an ack signal,
 * 					otherwise return 0.>
 * ��Parameter��:<Base_addr: The base address of IIC_Master device.>
 * ��  Example ��:<IIC_Master_check_ack(IIC_Master_0);
 * 				 The example will let IIC_Master device check an ack signal.>
 *------------------------------------------------------------------*/
uint8 IIC_Master_check_ack(AXI_BaseAddress_Data_Type Base_addr)
{
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_SEL0, IIC_Master_SEL0_CHECKACK);
	IIC_AXI_delay;
	AXI_Register_Data_Type CTL0_status = IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_CTL0);
	CTL0_status |= IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_BUSYIFG))==0x00);
	CTL0_status &= ~IIC_Master_START;
	IIC_MASTER_2_mWriteReg(Base_addr, IIC_Master_CTL0,CTL0_status);
	while(((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&(IIC_Master_EVENTIFG))==0x00);

	return (((IIC_MASTER_2_mReadReg(Base_addr, IIC_Master_IFG))&IIC_Master_ACKCHECKIFG)==IIC_Master_ACKCHECKIFG);
}

/*
 * main.c
 *
 *  Created on: 2022��3��6��
 *      Author: 93793
 */


#include "..\user\headfile.h"
//#include "Tri_gat.h"

unsigned char txt[40];

#define IIC_Master_Base_addr 0x43C00000
#define Tti_io_addr          0x43C10000

void IIC_init(void)
{
	//����ģ��ʱ��
	IIC_Master_disable(IIC_Master_0);//����IIC
	IIC_Master_unlockeddiv(IIC_Master_0);//����IIC ��Ƶ�Ĵ���
	IIC_Master_write_DIV0(IIC_Master_0,400);//����IIC ʱ��  IIC_CLK = ģ��ʱ��Ƶ��/10
	IIC_Master_write_DIV1(IIC_Master_0,100);//����IIC �������  pulse_width = 10*IIC_CLK
	IIC_Master_lockeddiv(IIC_Master_0);//����IIC ��Ƶ�Ĵ���
	IIC_Master_reset(IIC_Master_0);//��λIIC
	IIC_Master_enable(IIC_Master_0);//ʹ��IIC
}

int main()
{
	//IIC_init();
	EPROM_IIC_init();
	//TRI_GAT_mWriteReg(0x43C10000, 0x00, 0x01);
	//TRI_GAT_mWriteReg(0x43C10000, 0x04, 0x00);
	 EEPROM_write_double(0 , 0x00 , 0.3121);
	//xil_printf("%d \n",);
	while(1)
	{
//		IIC_Master_send_start(IIC_Master_0);
//	    IIC_Master_send_byte(IIC_Master_0,0x70);
//	    IIC_Master_send_nack(IIC_Master_0);
//	    IIC_Master_send_byte(IIC_Master_0,0x33);
//		IIC_Master_send_nack(IIC_Master_0);
//		IIC_Master_send_byte(IIC_Master_0,0xef);
//		IIC_Master_send_ack(IIC_Master_0);
//		IIC_Master_send_stop(IIC_Master_0);

		//usleep(500000);
//		xil_printf("READ:%d \n",EEPROM_write_Byte(0x00 , 0x00,1));
//		usleep(500000);
		sprintf(txt,"%.4f \n",EEPROM_read_double(0x00,0x00));
		xil_printf(txt);
		usleep(500000);
//		xil_printf("CHECK:%d \n",IIC_Master_check_ack(IIC_Master_0));
//		usleep(500000);
		//xil_printf("IO:%d \n",TRI_GAT_mReadReg(0x43C10000,0x0C));
		//usleep(500000);
	}

	return 0;
}


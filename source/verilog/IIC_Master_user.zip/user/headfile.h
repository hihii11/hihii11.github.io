/*
 * headfile.h
 *
 *  Created on: 2022��3��4��
 *      Author: 93793
 */

#ifndef USER_HEADFILE_H_
#define USER_HEADFILE_H_

//xilinx headfiles include
#include "stdio.h"
#include <stdlib.h>
#include "xparameters.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "sleep.h"
#include <math.h>
#include "xil_cache.h"
#include "xgpiops.h"
//user headfiles include
#include "dataconfig.h"
#include "IIC_Master_user.h"
#include "eeprom.h"

#endif /* USER_HEADFILE_H_ */

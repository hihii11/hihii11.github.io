/*
 * eeprom.h
 *
 *  Created on: 2022��3��8��
 *      Author: 93793
 */

#ifndef USER_EEPROM_H_
#define USER_EEPROM_H_

#define                   EEPROM_IIC_DEVICE_ADDR               (unsigned int)(IIC_Master_0)// <EEPROM IIC device base address define>
#define                   EEPROM_ADDR                          (unsigned int)(0x28)        // <EEPROM device address define>
#define                   EEPROM_DELAY                         usleep(20000)               // <wait for EEPROM to finish a write processing, it is necessary.
																						   // it will cause EEPROM write data error when the value of delay time is too small.>
//the union define

//_________________union_____________________
union short_chr
{
    short data;
    unsigned char data_buf[2];
}short_chr_convertor;

union int_chr
{
    int data;
    unsigned char data_buf[4];
}int_chr_convertor;

union flt_chr
{
    float data;
    unsigned char data_buf[4];
}flt_chr_convertor;

union dub_chr
{
    double data;
    unsigned char data_buf[8];
}dub_chr_convertor;
//______________________________________________

extern void EPROM_IIC_init(void);
extern uint8 EEPROM_write_Byte(uint8 page , uint8 addr , uint8 data);
extern uint8 EEPROM_read_Byte(uint8 page , uint8 addr);
extern uint8 EEPROM_write_len(uint8 page , uint8 addr , uint8 * data , uint8 len);
extern uint8 EEPROM_read_len(uint8 page , uint8 addr , uint8 * data_buf , uint8 len);
extern uint8 EEPROM_write_int(uint8 page , uint8 addr , int32 data);
extern uint8 EEPROM_write_short(uint8 page , uint8 addr , int16 data);
extern uint8 EEPROM_write_float(uint8 page , uint8 addr , float data );
extern uint8 EEPROM_write_double(uint8 page , uint8 addr , double data);
extern int32 EEPROM_read_int(uint8 page , uint8 addr);
extern int16 EEPROM_read_short(uint8 page , uint8 addr);
extern float EEPROM_read_float(uint8 page , uint8 addr);
extern double EEPROM_read_double(uint8 page , uint8 addr);

#endif /* USER_EEPROM_H_ */

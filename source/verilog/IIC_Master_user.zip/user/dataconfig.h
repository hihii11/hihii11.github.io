/*
 * dataconfig.h
 *
 *  Created on: 2022��3��5��
 *      Author: 93793
 */

#ifndef USER_DATACONFIG_H_
#define USER_DATACONFIG_H_

typedef                      unsigned int                       AXI_BaseAddress_Data_Type;
typedef                      unsigned int                          AXI_Register_Data_Type;


typedef                      unsigned int                                          uint32;
typedef                      signed int                                             int32;
typedef                      unsigned short                                        uint16;
typedef                      signed short                                           int16;
typedef                      unsigned char                                          uint8;
typedef                      signed char                                             int8;


#endif /* USER_DATACONFIG_H_ */
